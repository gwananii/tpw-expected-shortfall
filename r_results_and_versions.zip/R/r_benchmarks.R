# Competitors on the exported stress samples:
#  (1) Northrop, Attalides & Jonathan (2017) Bayesian leave-one-out threshold selection (threshr):
#      'nbest' = predictive from the best training threshold; 'nbma' = predictive averaged over
#      thresholds with the posterior threshold weights (their eq. 15), validation threshold = top.
#  (2) Bader, Yan & Zhang (2018) ForwardStop on Anderson-Darling p-values (eva), MLE at the chosen threshold.
suppressMessages({library(threshr); library(eva)}); options(warn = -1); set.seed(14)
# Usage:  Rscript R/r_benchmarks.R <sample folder> <output csv> [part] [nparts]
#   e.g.  Rscript R/r_benchmarks.R outputs/cache/full/rcomp outputs/cache/full/rcomp_out/part0.csv
# The folder holds index.csv (scenario, n, rep, file) and one CSV per sample (column x),
# written by export_rcomp_samples() or export_danish_samples().
# Packages: threshr (>= 1.0.8) and eva (>= 0.2.7).
args <- commandArgs(TRUE); folder <- args[1]; out_file <- args[2]
part <- if (length(args) >= 3) as.integer(args[3]) else 0L
nparts <- if (length(args) >= 4) as.integer(args[4]) else 1L
idx <- read.csv(file.path(folder, "index.csv"))
QS <- seq(0.85, 0.97, by = 0.01); LV <- c(0.975, 0.99, 0.995, 0.999); LE <- c(0.975, 0.99)
S_tail <- function(x, u, p, s, xi) {        # survival P(X > x), x >= u, for draw vectors
  z <- pmax(1 + xi * (x - u) / s, 0)
  ifelse(abs(xi) < 1e-8, p * exp(-(x - u) / s), p * z^(-1 / xi))
}
pred <- function(draws, a) {               # draws: list of data frames (u,p,s,xi,w) ; mixture predictive
  f <- function(x) sum(sapply(draws, function(d) d$w[1] * mean(S_tail(x, d$u, d$p, d$s, d$xi)))) - (1 - a)
  lo <- max(sapply(draws, function(d) d$u[1])); hi <- lo + 1
  if (f(lo) < 0) return(NA)
  k <- 0; while (f(hi) > 0 && k < 200) { hi <- lo + 2 * (hi - lo); k <- k + 1 }
  uniroot(f, c(lo, hi), tol = 1e-8)$root
}
pred_es <- function(draws, a, q) {         # q + E[(X - q)+] / (1 - a), draws with xi >= 1 dropped
  if (!is.finite(q)) return(NA)
  m <- sum(sapply(draws, function(d) { ok <- d$xi < 1
    d$w[1] * sum(S_tail(q, d$u[ok], d$p[ok], d$s[ok], d$xi[ok]) * (d$s[ok] + d$xi[ok] * (q - d$u[ok])) / (1 - d$xi[ok])) / nrow(d) }))
  q + m / (1 - a)
}
rows <- list()
for (i in which((seq_len(nrow(idx)) - 1) %% nparts == part)) {
  x <- read.csv(file.path(folder, idx$file[i]))$x; n <- length(x)
  u_vec <- unname(quantile(x, QS, type = 7))
  out <- data.frame(scenario = idx$scenario[i], n = idx$n[i], rep = idx$rep[i])
  t0 <- Sys.time()
  r <- tryCatch({
    fit <- suppressWarnings(ithresh(x, u_vec = u_vec, n = 2000))
    M <- length(u_vec); N <- fit$n
    ptw <- threshr:::post_thresh_weights(x = fit, which_v = 1, u_prior = rep(1, M))
    best <- which.max(fit$pred_perf[, 1])
    dr <- lapply(seq_along(ptw), function(j) { rr <- (1 + (j - 1) * N):(j * N)
      data.frame(u = u_vec[j], p = fit$sim_vals[rr, 1], s = fit$sim_vals[rr, 2], xi = fit$sim_vals[rr, 3], w = ptw[j]) })
    db <- dr[best]; db[[1]]$w <- 1
    for (a in LV) { out[[paste0("nbest_var", a)]] <- pred(db, a); out[[paste0("nbma_var", a)]] <- pred(dr[ptw > 1e-6], a) }
    for (a in LE) { out[[paste0("nbest_es", a)]] <- pred_es(db, a, out[[paste0("nbest_var", a)]])
                    out[[paste0("nbma_es", a)]] <- pred_es(dr[ptw > 1e-6], a, out[[paste0("nbma_var", a)]]) }
    out$nbest_q <- QS[best]; out$nbma_Neff <- 1 / sum(ptw^2); TRUE
  }, error = function(e) { out$nerr <<- conditionMessage(e); FALSE })
  out$nsec <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  r2 <- tryCatch({
    st <- tryCatch(gpdSeqTests(x, thresholds = u_vec, method = "ad"),
                   error = function(e) { out$fstop_boot <<- TRUE; gpdSeqTests(x, thresholds = u_vec, method = "ad", nsim = 199) })
    k <- suppressWarnings(max(which(st$ForwardStop <= 0.05)))
    j <- if (!is.finite(k)) 1 else min(k + 1, nrow(st))
    s <- st$est.scale[j]; xi <- st$est.shape[j]; u <- u_vec[j]; p <- st$num.above[j] / n
    for (a in LV) out[[paste0("fstop_var", a)]] <- u + s / xi * ((p / (1 - a))^xi - 1)
    for (a in LE) { v <- out[[paste0("fstop_var", a)]]; out[[paste0("fstop_es", a)]] <- if (xi < 1) (v + s - xi * u) / (1 - xi) else NA }
    out$fstop_q <- QS[j]; TRUE
  }, error = function(e) { out$ferr <<- conditionMessage(e); FALSE })
  rows[[length(rows) + 1]] <- out
  if (length(rows) %% 20 == 0) cat(part, length(rows), format(Sys.time()), "\n")
}
all <- do.call(function(...) Reduce(function(a, b) merge(a, b, all = TRUE), list(...)), rows)
dir.create(dirname(out_file), showWarnings = FALSE, recursive = TRUE)
write.csv(all, out_file, row.names = FALSE)
