# Expected quantile discrepancy (EQD) threshold selection of Murphy, Tawn and Varty (2025, Technometrics),
# as implemented in the R package mev (>= 2.2, function thselect.vmetric, type = "eqd",
# defaults B = 199, L1 distance, nonparametric bootstrap), on the grid of 13 thresholds.
# VaR and ES from the GPD maximum likelihood fit at the selected threshold.
# Usage: Rscript R/eqd.R <sample folder with index.csv> <output csv> [part] [nparts]
suppressMessages(library(mev)); options(warn = -1); set.seed(2024)
args <- commandArgs(TRUE); folder <- args[1]; out_file <- args[2]
part <- if (length(args) >= 3) as.integer(args[3]) else 0L
nparts <- if (length(args) >= 4) as.integer(args[4]) else 1L
idx <- read.csv(file.path(folder, "index.csv"))
QS <- seq(0.85, 0.97, by = 0.01); LV <- c(0.975, 0.99, 0.995, 0.999); LE <- c(0.975, 0.99)
rows <- list()
for (i in which((seq_len(nrow(idx)) - 1) %% nparts == part)) {
  x <- read.csv(file.path(folder, idx$file[i]))$x; n <- length(x)
  u_vec <- unname(quantile(x, QS, type = 7))
  out <- data.frame(scenario = idx$scenario[i], n = idx$n[i], rep = idx$rep[i])
  t0 <- Sys.time()
  ok <- tryCatch({
    r <- thselect.vmetric(xdat = x, thresh = u_vec, type = "eqd")
    j <- which.min(r$metric); u <- u_vec[j]; s <- r$scale[j]; xi <- r$shape[j]; p <- mean(x > u)
    for (a in LV) out[[paste0("eqd_var", a)]] <- if (abs(xi) < 1e-8) u - s * log((1 - a) / p) else u + s / xi * (((1 - a) / p)^(-xi) - 1)
    for (a in LE) { v <- out[[paste0("eqd_var", a)]]; out[[paste0("eqd_es", a)]] <- if (xi < 1) (v + s - xi * u) / (1 - xi) else NA }
    out$eqd_q <- QS[j]; out$eqd_xi <- xi; TRUE
  }, error = function(e) { out$eqd_err <<- conditionMessage(e); FALSE })
  out$nsec <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  rows[[length(rows) + 1]] <- out
  if (length(rows) %% 25 == 0) cat(part, length(rows), format(Sys.time()), "\n")
}
all <- do.call(function(...) Reduce(function(a, b) merge(a, b, all = TRUE), list(...)), rows)
dir.create(dirname(out_file), showWarnings = FALSE, recursive = TRUE)
write.csv(all, out_file, row.names = FALSE)
